import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Calendar, Users, DollarSign, MapPin, Loader2, Hotel, Star } from 'lucide-react';
import { tripsAPI, hotelsAPI, itinerariesAPI } from '../services/api';
import { format } from 'date-fns';

export default function TripDetailPage() {
  const { id } = useParams();
  const [trip, setTrip] = useState(null);
  const [hotels, setHotels] = useState([]);
  const [itinerary, setItinerary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchingHotels, setSearchingHotels] = useState(false);
  const [generatingItinerary, setGeneratingItinerary] = useState(false);

  useEffect(() => {
    fetchTripData();
  }, [id]);

  const fetchTripData = async () => {
    try {
      const tripResponse = await tripsAPI.getOne(id);
      setTrip(tripResponse.data);
      
      // Try to fetch itinerary
      try {
        const itineraryResponse = await itinerariesAPI.get(id);
        setItinerary(itineraryResponse.data);
      } catch (error) {
        // Itinerary doesn't exist yet
      }
    } catch (error) {
      console.error('Error fetching trip:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchHotels = async () => {
    if (!trip) return;
    setSearchingHotels(true);
    
    try {
      const response = await hotelsAPI.search({
        destination: trip.destination,
        checkin: trip.start_date,
        checkout: trip.end_date,
        max_results: 10,
      });
      setHotels(response.data);
    } catch (error) {
      console.error('Error searching hotels:', error);
      alert('Failed to search hotels. Please try again.');
    } finally {
      setSearchingHotels(false);
    }
  };

  const generateItinerary = async () => {
    setGeneratingItinerary(true);
    try {
      const response = await itinerariesAPI.generate(id);
      setItinerary(response.data);
    } catch (error) {
      console.error('Error generating itinerary:', error);
      alert('Failed to generate itinerary. Please try again.');
    } finally {
      setGeneratingItinerary(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-12 w-12 text-primary-600 animate-spin" />
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-xl text-gray-600">Trip not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Trip Header */}
        <div className="card p-8 mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">{trip.destination}</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="flex items-center space-x-3">
              <Calendar className="h-6 w-6 text-primary-600" />
              <div>
                <p className="text-sm text-gray-500">Dates</p>
                <p className="font-semibold">{format(new Date(trip.start_date), 'MMM dd')} - {format(new Date(trip.end_date), 'MMM dd')}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Users className="h-6 w-6 text-primary-600" />
              <div>
                <p className="text-sm text-gray-500">Travelers</p>
                <p className="font-semibold">{trip.travelers}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <DollarSign className="h-6 w-6 text-primary-600" />
              <div>
                <p className="text-sm text-gray-500">Budget</p>
                <p className="font-semibold">{trip.budget}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <MapPin className="h-6 w-6 text-primary-600" />
              <div>
                <p className="text-sm text-gray-500">Interests</p>
                <p className="font-semibold">{trip.interests || 'General'}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Hotels Section */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-gray-900">Hotels</h2>
            <button
              onClick={searchHotels}
              disabled={searchingHotels}
              className="btn-primary"
            >
              {searchingHotels ? (
                <>
                  <Loader2 className="animate-spin h-5 w-5 mr-2" />
                  Searching...
                </>
              ) : (
                'Search Hotels'
              )}
            </button>
          </div>

          {hotels.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {hotels.map((hotel) => (
                <div key={hotel.id} className="card overflow-hidden card-hover">
                  {hotel.image_url && (
                    <img
                      src={hotel.image_url}
                      alt={hotel.name}
                      className="w-full h-48 object-cover"
                    />
                  )}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{hotel.name}</h3>
                    <p className="text-sm text-gray-600 mb-4 flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {hotel.location}
                    </p>
                    
                    <div className="flex justify-between items-center mb-4">
                      <div className="text-2xl font-bold text-primary-600">
                        ₹{hotel.price_per_night.toLocaleString()}
                        <span className="text-sm text-gray-500 font-normal">/night</span>
                      </div>
                      {hotel.rating && (
                        <div className="flex items-center">
                          <Star className="h-5 w-5 text-yellow-400 fill-current mr-1" />
                          <span className="font-semibold">{hotel.rating}</span>
                        </div>
                      )}
                    </div>
                    
                    {hotel.booking_url && (
                      <a
                        href={hotel.booking_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-center btn-secondary w-full"
                      >
                        View Details
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="card p-12 text-center">
              <Hotel className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Click "Search Hotels" to find accommodations</p>
            </div>
          )}
        </div>

        {/* Itinerary Section */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-gray-900">AI Itinerary</h2>
            {!itinerary && (
              <button
                onClick={generateItinerary}
                disabled={generatingItinerary}
                className="btn-primary"
              >
                {generatingItinerary ? (
                  <>
                    <Loader2 className="animate-spin h-5 w-5 mr-2" />
                    Generating...
                  </>
                ) : (
                  'Generate Itinerary'
                )}
              </button>
            )}
          </div>

          {itinerary ? (
            <div className="card p-8">
              <div className="prose max-w-none">
                <pre className="whitespace-pre-wrap font-sans text-gray-700">
                  {itinerary.content}
                </pre>
              </div>
            </div>
          ) : (
            <div className="card p-12 text-center">
              <p className="text-gray-500">Click "Generate Itinerary" to create your personalized travel plan</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
