import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Calendar, Users, DollarSign, Heart, Loader2 } from 'lucide-react';
import { tripsAPI } from '../services/api';
import { format, addDays } from 'date-fns';

export default function PlanTripPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    destination: '',
    start_date: format(addDays(new Date(), 7), 'yyyy-MM-dd'),
    end_date: format(addDays(new Date(), 10), 'yyyy-MM-dd'),
    budget: 'Mid-range',
    interests: '',
    travelers: 2,
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await tripsAPI.create(formData);
      const tripId = response.data.id;
      navigate(`/trips/${tripId}`);
    } catch (error) {
      console.error('Error creating trip:', error);
      alert('Failed to create trip. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const budgetOptions = ['Budget', 'Mid-range', 'Luxury'];
  const interestSuggestions = [
    'Beach', 'Mountains', 'Culture', 'Adventure', 'Food', 
    'Shopping', 'Nightlife', 'Nature', 'History', 'Photography'
  ];

  const [selectedInterests, setSelectedInterests] = useState([]);

  const toggleInterest = (interest) => {
    const updated = selectedInterests.includes(interest)
      ? selectedInterests.filter(i => i !== interest)
      : [...selectedInterests, interest];
    
    setSelectedInterests(updated);
    setFormData({ ...formData, interests: updated.join(', ') });
  };

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10 animate-fade-in">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Plan Your <span className="gradient-text">Perfect Trip</span>
          </h1>
          <p className="text-xl text-gray-600">
            Tell us about your dream destination and let AI do the magic
          </p>
        </div>

        <form onSubmit={handleSubmit} className="card p-8 sm:p-10 animate-slide-up">
          {/* Destination */}
          <div className="mb-8">
            <label className="flex items-center text-lg font-semibold text-gray-700 mb-3">
              <MapPin className="h-5 w-5 mr-2 text-primary-600" />
              Where do you want to go?
            </label>
            <input
              type="text"
              name="destination"
              value={formData.destination}
              onChange={handleChange}
              placeholder="e.g., Goa, India"
              className="input-field text-lg"
              required
            />
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
            <div>
              <label className="flex items-center text-lg font-semibold text-gray-700 mb-3">
                <Calendar className="h-5 w-5 mr-2 text-primary-600" />
                Start Date
              </label>
              <input
                type="date"
                name="start_date"
                value={formData.start_date}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>
            <div>
              <label className="flex items-center text-lg font-semibold text-gray-700 mb-3">
                <Calendar className="h-5 w-5 mr-2 text-primary-600" />
                End Date
              </label>
              <input
                type="date"
                name="end_date"
                value={formData.end_date}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>
          </div>

          {/* Budget & Travelers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
            <div>
              <label className="flex items-center text-lg font-semibold text-gray-700 mb-3">
                <DollarSign className="h-5 w-5 mr-2 text-primary-600" />
                Budget
              </label>
              <select
                name="budget"
                value={formData.budget}
                onChange={handleChange}
                className="input-field"
                required
              >
                {budgetOptions.map(option => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="flex items-center text-lg font-semibold text-gray-700 mb-3">
                <Users className="h-5 w-5 mr-2 text-primary-600" />
                Travelers
              </label>
              <input
                type="number"
                name="travelers"
                value={formData.travelers}
                onChange={handleChange}
                min="1"
                max="20"
                className="input-field"
                required
              />
            </div>
          </div>

          {/* Interests */}
          <div className="mb-8">
            <label className="flex items-center text-lg font-semibold text-gray-700 mb-3">
              <Heart className="h-5 w-5 mr-2 text-primary-600" />
              What interests you?
            </label>
            <div className="flex flex-wrap gap-3 mb-4">
              {interestSuggestions.map(interest => (
                <button
                  key={interest}
                  type="button"
                  onClick={() => toggleInterest(interest)}
                  className={`px-4 py-2 rounded-full font-medium transition-all ${
                    selectedInterests.includes(interest)
                      ? 'bg-primary-600 text-white shadow-md'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {interest}
                </button>
              ))}
            </div>
            <input
              type="text"
              name="interests"
              value={formData.interests}
              onChange={handleChange}
              placeholder="Or type your own interests (comma-separated)"
              className="input-field"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full text-lg py-4 flex items-center justify-center"
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin h-6 w-6 mr-3" />
                Creating Your Trip...
              </>
            ) : (
              'Create My Trip Plan'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
