import { Link } from 'react-router-dom';
import { Sparkles, TrendingUp, Shield, Zap } from 'lucide-react';

export default function HomePage() {
  const features = [
    {
      icon: Sparkles,
      title: 'AI-Powered Planning',
      description: 'Get personalized itineraries crafted by advanced AI',
    },
    {
      icon: TrendingUp,
      title: 'Real-Time Prices',
      description: 'Live hotel prices and availability from top booking sites',
    },
    {
      icon: Shield,
      title: 'Budget Friendly',
      description: 'Stay within budget with smart recommendations',
    },
    {
      icon: Zap,
      title: 'Instant Results',
      description: 'Get your complete trip plan in seconds',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-purple-50 to-pink-50 opacity-70"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32">
          <div className="text-center animate-fade-in">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight mb-8">
              <span className="block text-gray-900">Plan Your Dream</span>
              <span className="block gradient-text">Trip with AI</span>
            </h1>
            
            <p className="max-w-2xl mx-auto text-xl sm:text-2xl text-gray-600 mb-12">
              Let artificial intelligence create the perfect itinerary for your next adventure.
              Hotels, activities, and budget - all planned in seconds.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link
                to="/plan"
                className="btn-primary text-lg px-8 py-4 w-full sm:w-auto"
              >
                Start Planning Now
              </Link>
              <Link
                to="/trips"
                className="btn-secondary text-lg px-8 py-4 w-full sm:w-auto"
              >
                View My Trips
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="section-title">Why Choose AI Travel Planner?</h2>
            <p className="text-xl text-gray-600">
              Powered by cutting-edge technology to give you the best experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="card p-8 text-center card-hover animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="inline-flex items-center justify-center w-16 h-16 mb-6 bg-gradient-to-br from-primary-100 to-purple-100 rounded-2xl">
                  <feature.icon className="h-8 w-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-primary-100 mb-8">
            Join thousands of travelers who trust AI to plan their perfect trips
          </p>
          <Link
            to="/plan"
            className="inline-block bg-white text-primary-600 font-bold py-4 px-10 rounded-xl shadow-xl hover:shadow-2xl transform hover:-translate-y-1 transition-all duration-200 text-lg"
          >
            Plan My Trip Now
          </Link>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold gradient-text mb-2">10K+</div>
              <div className="text-gray-600">Trips Planned</div>
            </div>
            <div>
              <div className="text-4xl font-bold gradient-text mb-2">500+</div>
              <div className="text-gray-600">Destinations</div>
            </div>
            <div>
              <div className="text-4xl font-bold gradient-text mb-2">98%</div>
              <div className="text-gray-600">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
