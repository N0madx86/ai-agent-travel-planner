import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import PlanTripPage from './pages/PlanTripPage';
import MyTripsPage from './pages/MyTripsPage';
import TripDetailPage from './pages/TripDetailPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/plan" element={<PlanTripPage />} />
            <Route path="/trips" element={<MyTripsPage />} />
            <Route path="/trips/:id" element={<TripDetailPage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
